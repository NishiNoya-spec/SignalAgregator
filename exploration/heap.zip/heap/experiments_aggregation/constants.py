import json

with open(r'D:\zharikova_ep\cv_projects\9684_dev\exploration\experiments_aggregation\min_data.json') as json_file:
    MIN = json.load(json_file)

with open(r'D:\zharikova_ep\cv_projects\9684_dev\exploration\experiments_aggregation\max_data.json') as json_file:
    DIFF_MAX = json.load(json_file)

