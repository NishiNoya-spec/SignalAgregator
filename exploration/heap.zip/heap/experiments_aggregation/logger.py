import logging

agg_handler = logging.FileHandler('aggregation.log')
formatter = logging.Formatter("%(asctime)s ----- %(levelname)s ---- %(threadName)s:    %(message)s")
agg_handler.setFormatter(formatter)
agg_logger = logging.getLogger('agg_logger')
agg_logger.setLevel(logging.INFO)
agg_logger.addHandler(agg_handler)

logger = agg_logger
