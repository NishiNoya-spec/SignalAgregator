import os
import re

from experiments_aggregation.utils import create_save_path
from exploration.experiments_aggregation import dto
from exploration.experiments_aggregation.logger import logger
from exploration.experiments_aggregation.dto import Source, Segment
from typing import Dict, Tuple
from dataclasses import dataclass
from glob import glob
import pandas as pd
from multiprocessing.pool import Pool
from datetime import datetime


@dataclass
class MappingCreator:
    constants: dto.Constants

    def get_metadata(self):
        billets_info = list()
        metadata_files = glob(self.constants.PATH_TO_METADATA)

        if not metadata_files:
            error_msg = "Не найдено файлов Metadata. Процесс остановлен"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        for metadata_path in glob(self.constants.PATH_TO_METADATA):
            metadata = pd.read_excel(metadata_path, engine='openpyxl')
            metadata[self.constants.METADATA_BILLET_ID] = \
                "Л2" + \
                metadata["Плавка"].str.split("-", expand=True).iloc[:, -1] + \
                metadata["Руч"].astype(str) + "0" + \
                metadata["Заг"].astype(str) + "_" + \
                metadata["Вр.реза"].dt.year.astype(str)

            if self.constants.MARK_FILTER is True:
                metadata = metadata[metadata["Марка"].isin(self.constants.MARK)]
            billets_info.append(metadata[[
                "Вр.проката", "BilletId", "Марка"]].dropna())
        billets_metadata = pd.concat(billets_info)
        logger.info(f"Обнаружено {len(metadata_files)} файл(а) Metadata, "
                    f"в которых содержатся данные {billets_metadata.shape[0]} "
                    f"плавок")
        return pd.concat(billets_info)

    def create_mapping(self, metadata: pd.DataFrame,
                       settings: Dict[str, Source],
                       time_period: str) -> Tuple[dict, pd.DataFrame]:

        report_dir = create_save_path(self.constants.PATH_TO_RESULT, 'reports')
        save_path = os.path.join(report_dir, f'report_{time_period}.csv')

        sources = {}
        for source_name, source in settings.items():
            filepaths = []

            files_folders = self._get_key_folders(
                main_folder=source.main_folder,
                key=source.key_folder)
            for folder in files_folders:
                filepaths.extend(glob(os.path.join(
                    folder, f"{source.nested_folders}/*csv")))

            filtered_filepaths = []
            for filepath in filepaths:
                if source.filename_key in filepath:
                    filtered_filepaths.append(filepath)

            if not filtered_filepaths:
                error_msg = f"Не найдено файлов источника {source_name}. " \
                            f"Процесс остановлен"
                logger.error(error_msg)
                raise FileNotFoundError(error_msg)
            else:
                logger.info(f"Обнаружено {len(filtered_filepaths)} "
                            f"файлов источника {source_name}")

            with Pool(self.constants.NUM_OF_CORES) as pool:
                billets = pool.map(self._get_billet_id, filtered_filepaths)
            sources[source_name] = dict([billet for billet in billets[:]
                                         if billet is not None])

        by_billets = dict()

        not_use_billets = {key: [] for key in sources.keys()}
        not_use_billets["BilletId"] = []
        not_use_billets["Time"] = []
        for billet_id in metadata[self.constants.METADATA_BILLET_ID].to_list():
            if all([billet_id in billet_ids
                    for _, billet_ids in sources.items()]):
                by_billets[billet_id] = dict(
                    [(source, sources[source][billet_id])
                     for source in sources])
            else:
                not_use_billets["BilletId"].append(billet_id)
                not_use_billets["Time"].append(metadata[metadata[self.constants.METADATA_BILLET_ID] == billet_id]["Вр.проката"].iloc[0])
                for source, billet_ids in sources.items():
                    not_use_billets[source].append(int(billet_id in billet_ids))
        logger.info(f"Создание маппинга завершено. Всего обнаружено "
                    f"{len(by_billets)} уникальных заготовок")

        not_use_billets = pd.DataFrame(not_use_billets)
        source_columns = list(sources.keys())
        not_use_billets["fullness"] = not_use_billets[source_columns].sum(axis=1).astype(str) + "/" + str(len(source_columns))
        not_use_billets = not_use_billets[["Time", self.constants.METADATA_BILLET_ID,] + source_columns + ["fullness"]]
        not_use_billets.to_csv(save_path, sep=";", decimal=",")
        return by_billets, not_use_billets

    def _get_billet_id(self, filepath: str) -> (str, str):
        file_name, file_ext = os.path.basename(filepath).split('.')
        if "_L" in file_name:
            if re.findall(r'Л\d{8}', file_name):
                billet_id = re.findall(r'Л\d{8}', file_name)[0]
                return self._get_billet_from_period(file_name[:14], billet_id, filepath)

            elif re.findall(r'\d{5}X\d{3}', file_name):
                billet_id = re.findall(r'\d{5}X\d{3}', file_name)
                billet_id = "Л" + billet_id[0].replace("X", "")
                return self._get_billet_from_period(file_name[:14], billet_id, filepath)

    def _get_billet_from_period(self, date: str, billet_id: str, filepath):
        billet_time = datetime.strptime(date, "%Y%m%d%H%M%S")
        if self._is_billet_in_period(billet_time):
            return f"{billet_id}_{billet_time.year}", filepath

    def _is_billet_in_period(self, billet_time):
        return billet_time >= self.constants.MIN_TIME and billet_time <= self.constants.MAX_TIME

    def _get_key_folders(self, main_folder: str, key: str) -> list:
        folders = []
        for (_, directories, _) in os.walk(main_folder):
            if key in directories:
                return [os.path.join(main_folder, f"{key}")]
            elif not directories:
                return []
            else:
                for directory in directories:
                    folders.extend(self._get_key_folders(os.path.join(
                        main_folder, directory), key))
                return folders
