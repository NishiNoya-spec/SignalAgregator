import warnings
from dataclasses import dataclass

from exploration.experiments_aggregation.constants import MIN, DIFF_MAX
from exploration.experiments_aggregation.dto import Source
from typing import List

import numpy as np
import pandas as pd

from exploration.experiments_aggregation import dto


@dataclass
class DataGenerator:
    constants: dto.Constants

    @staticmethod
    def generate_secondary_features(data: pd.DataFrame, settings: Source):
        for colname_1, values_1 in data.iteritems():
            # Пропускаем колонку с биллетами
            if colname_1 == settings.billet_column:
                continue

            # Синтетические фичи
            if "abs" in settings.synthetic_methods:
                data[f"abs_{colname_1}"] = abs(values_1)
            if "norm" in settings.synthetic_methods:
                try:
                    data[f"norm_{colname_1}"] = (values_1 - MIN[colname_1]) / (DIFF_MAX[colname_1] - MIN[colname_1])
                except KeyError:
                    pass
            if "mult" in settings.synthetic_methods:
                for colname_2, values_2 in data.iteritems():
                    if colname_1 == settings.billet_column:
                        continue
                    data[f"mult_{colname_1}_{colname_2}"] = values_1 * values_2
        return data
