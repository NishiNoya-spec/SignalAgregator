from abc import ABC
from dataclasses import dataclass
from typing import List, Optional, Dict
from datetime import datetime


@dataclass
class Segment:
    start_point: float
    end_point: float
    target_segments: List[str]


@dataclass
class Source:
    type: str
    main_folder: str
    key_folder: str
    nested_folders: str
    filename_key: str
    interpolation_type: str
    interpolation: Optional[str]
    segments: Dict[str, Segment]
    forbidden_columns: List[str]
    synthetic_methods: List[str]
    aggregation_methods: List[str]
    billet_column: str


@dataclass
class Constants(ABC):
    MIN_TIME: datetime  # ограничение файлов по минимальной дате
    MAX_TIME: datetime  # ограничение файлов по максимальной дате
    NUM_OF_CORES: int  # количество выделенных ядер ЦПУ
    MARK_FILTER: bool  # фильтровать или нет марки рельс
    MARK: List[str]  # марка рельса
    PATH_TO_METADATA: str  # пути до данных
    PATH_TO_RESULT: str  # путь до папки с результатом. Создавать самостоятельно
    METADATA_BILLET_ID: str  # имя столбца с ИД заготовки


