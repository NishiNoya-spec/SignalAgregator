import numpy as np
import pandas as pd
from exploration.experiments_aggregation.dto import Source, Segment
from typing import Dict
import ast


def parse_settings(settings: pd.DataFrame) -> Dict[str, Source]:
    sources = {}
    for _, source_settings in settings.iteritems():
        # Парсим сегменты
        segments = {}
        for segment_data in str(source_settings["segments"]).split("\n"):
            segment_id, start, end, target_ids = eval(segment_data)
            segments[f"{source_settings['source']}_{segment_id}"] = Segment(
                start_point=start,
                end_point=end,
                target_segments=target_ids
            )

        # Парсим остальные настройки источника
        if source_settings['interpolation_type'] == 'by value':
            interp = float(source_settings['interpolation'])
        elif source_settings['interpolation_type'] == 'by source':
            interp = source_settings['interpolation']
        elif np.isnan(source_settings['interpolation_type']):
            interp = None
        else:
            raise NameError(f"Unknown interpolation type for source "
                            f"{source_settings['source']}")
        source_settings = source_settings.fillna("")
        sources[source_settings['source']] = Source(
            type=source_settings['type'],
            main_folder=source_settings['main_folder'],
            key_folder=source_settings['key_folder'],
            nested_folders=source_settings['nested_folders'],
            filename_key=source_settings['filename_key'],
            interpolation_type=source_settings['interpolation_type'],
            billet_column=source_settings['billet_column'],
            interpolation=interp,
            segments=segments,
            forbidden_columns=ast.literal_eval(
                source_settings['forbidden_columns']),
            synthetic_methods=ast.literal_eval(
                source_settings['synthetic_methods']),
            aggregation_methods=ast.literal_eval(
                source_settings['agg_methods']),
        )

    return sources
