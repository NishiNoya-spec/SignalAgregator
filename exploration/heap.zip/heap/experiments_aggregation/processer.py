from exploration.experiments_aggregation import dto, decomposer, new_generator
from exploration.experiments_aggregation.dto import Source, Segment
from exploration.experiments_aggregation.logger import logger
from dataclasses import dataclass
from typing import Dict
import pandas as pd


@dataclass
class Processer:
    metadata: pd.DataFrame
    constants: dto.Constants
    data_mapping: dict
    sources_settings: Dict[str, Source]

    def create_data_batch(self, billet_id):

        try:
            data_aggregator = decomposer.Decomposer(
                constants=self.constants,
                sources_settings=self.sources_settings)
            data_generator = new_generator.DataGenerator(
                constants=self.constants)

            pre_aggregated_sources, aggregated_sources = {}, {}
            for source, filepath in self.data_mapping[billet_id].items():
                data = pd.read_csv(filepath, sep=";", decimal=",")
                settings = self.sources_settings[source]
                data = data.drop(columns=settings.forbidden_columns)
                data = data[data[settings.billet_column].notna()]
                for column in data.columns:
                    if column == settings.billet_column:
                        continue
                    data = data.rename(
                        columns={column: f"{source}_{column}"})
                data = data_generator.generate_secondary_features(
                    data, settings)
                pre_aggregated_sources[source] = data

            for source, _ in pre_aggregated_sources.items():
                data = self._interpolate_source(source, pre_aggregated_sources)
                aggregated_data = data_aggregator.aggregate_segments(
                    data, source)
                aggregated_sources[source] = aggregated_data
            batch_aggregation = data_aggregator.aggregate_by_method(
                aggregated_sources, billet_id)
            logger.error(f"Успешно. Заготовка {billet_id}")
            return batch_aggregation
        except Exception:
            print(f"Ошибка. Заготовка {billet_id}")
            logger.error(f"Ошибка. Заготовка {billet_id}")
            logger.exception('')

    def _interpolate_source(self, source: str, pre_data: dict):
        'Интерполяция'
        settings = self.sources_settings[source]
        data = pre_data[source]
        if settings.interpolation_type == 'by value':
            max_billet = max(data[settings.billet_column])
            data[settings.billet_column] = (
                    data[settings.billet_column]
                    * settings.interpolation / max_billet)
            for column in data.columns:
                if column == settings.billet_column:
                    continue
                data = data.rename(
                    columns={column: f"{column}_"
                                     f"[i_{settings.interpolation:.1f}]"})
        elif settings.interpolation_type == 'by source':
            max_billet = max(data[settings.billet_column])
            max_source_billet = max(
                pre_data[source][self.sources_settings[source].billet_column])
            data[settings.billet_column] = (
                    data[settings.billet_column]
                    * max_source_billet / max_billet)
            for column in data.columns:
                if column == settings.billet_column:
                    continue
                data = data.rename(
                    columns={column: f"{column}_[i_{max_source_billet:.1f}]"})
        else:
            for column in data.columns:
                if column == settings.billet_column:
                    continue
                data = data.rename(columns={column: f"{column}_[ni]"})
        return data
