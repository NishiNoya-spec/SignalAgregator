import pandas as pd

from exploration.twisted_rails.ipsrnk_analisys.analisys_pipeline import \
    Analyser
from exploration.twisted_rails.ipsrnk_analisys.constants import (
    COLUMNS_TO_DROP, DATA_PATH)
from exploration.twisted_rails.ipsrnk_analisys.trainer import Trainer

if __name__ == "__main__":
    data = pd.read_csv(DATA_PATH, ).drop(COLUMNS_TO_DROP, axis=1)
    data.columns = [col.replace('.', '_') for col in data.columns]
    use_columns = [
        col for col in data.columns if "tail" not in col and "0_3" not in col
    ]
    data = data[use_columns]
    cut_info = pd.read_csv("path/to/cut_info.csv", ).rename(
        {"Unnamed: 0": "BilletId"}, axis="columns")

    # data = pd.merge(data, cut_info, on="BilletId")

    # data.to_csv("test.csv")

    # filtered_data = data
    filtered_data = data[(data["defect_crate"] == "A")].drop(
        ["defect_crate", "BilletId"], axis=1).drop_duplicates(keep="first")
    # filtered_data = data[(data["defect_crate"] == "Y")].drop(["defect_crate",
    # "BilletId",], axis=1).drop_duplicates(keep="first")
    # filtered_data = data[(data["defect_crate"] != "A") &
    # (data["defect_crate"] != "Y")].drop(["defect_crate", "BilletId"], axis=1).drop_duplicates(keep="first")
    # filtered_data = data[(data["defect_crate"] == "A;B;C;Y")].drop(
    #     ["defect_crate", "BilletId"], axis=1).drop_duplicates(keep="first")

    # filtered_data = data[(data["defect_crate"] == "B") |
    #                      (data["defect_crate"] == "C")].drop(["defect_crate"],
    #                                                          axis=1).drop_duplicates()
    analyser = Analyser(data=filtered_data)
    features = analyser.analyse()

    trainer = Trainer(filtered_data, features)
    trainer.train_classification(shufl_data=True)
