import os

import pandas as pd

IPSRNK_PATH = r"path/to/preprocess/data"

if __name__ == '__main__':
    crates = {
        "A": [0, 25],
        "B": [25, 50],
        "C": [50, 75],
        "Y": [75, 103],
    }
    table = str.maketrans({'A': '', 'B': '', 'C': '', 'Y': ''})
    df = pd.read_excel("ИТС — копия.xlsx",
                       usecols=[
                           "дата_прокатки", "марка", "рельс", "дефект_одп",
                           "дефект_тооз", "Дефект_отгрузка100", "загот"
                       ]).fillna("")
    df = df[(df["марка"] == "Э76ХФ") | (df["марка"] == "Э90ХАФ")]
    df["дефект"] = df["дефект_одп"] + df["дефект_тооз"] + df[
        "Дефект_отгрузка100"]
    df = df[df["дефект"].str.contains("концевая скрученность") |
            (df["дефект"] == "")]
    df["дефект"] = df["дефект"].str.contains("концевая скрученность").astype(
        int)
    df["defect_crate"] = df["рельс"].str.replace('\d+', '')
    df["загот"] = df["загот"].str[:-1] + "_" + df[
        "дата_прокатки"].dt.year.astype(str)
    df = df.drop([
        "дата_прокатки", "марка", "рельс", "дефект_одп", "дефект_тооз",
        "Дефект_отгрузка100"
    ],
                 axis=1)

    peredel_df = [df]
    for postfix in ["", "_2"]:
        new_df = pd.read_excel(f"Отчет brak_peredel{postfix}.xlsx",
                               usecols=["№ Рельса", "Дата"
                                        ]).rename({
                                            "№ Рельса": "загот"
                                        },
                                                  axis="columns").dropna()
        new_df["загот"] = new_df[(new_df["загот"].str.len() >= 9) & (
            new_df["загот"].str.len() <= 10)]["загот"].str[:9]
        new_df["дефект"] = 1
        new_df["defect_crate"] = new_df["загот"].str.replace('\d+', '')
        new_df["загот"] = "Л" + new_df["загот"].str.translate(
            table) + new_df["Дата"].dt.year.astype(str)
        new_df = new_df.drop(["Дата"], axis=1)
        peredel_df.append(new_df)

    df = pd.concat(peredel_df)

    ipsrnk = []
    for ipsrnk_file in os.listdir(IPSRNK_PATH):
        if ".csv" in ipsrnk_file:
            ipsrnk_file_path = os.path.join(IPSRNK_PATH, ipsrnk_file)
            ipsrnk_data = pd.read_csv(ipsrnk_file_path,
                                      usecols=[
                                          'Torsion_max',
                                          'Torsion_min',
                                          'Torsion_mean',
                                          'Torsion_median',
                                          'Torsion_std',
                                          'abs_Torsion_max',
                                          'abs_Torsion_mean',
                                          'abs_Torsion_median',
                                          'abs_Torsion_std',
                                          'BilletId',
                                      ]).set_index('BilletId')
            postfix = ipsrnk_file.split("_")[:3]
            postfix = "_".join(postfix)
            ipsrnk_data.columns = [
                column + "_" + postfix for column in ipsrnk_data.columns
            ]  # 0_3_head_01062022_22052023.csv
            ipsrnk.append(ipsrnk_data)

    ipsrnk = pd.concat(ipsrnk, axis=1).reset_index()

    result = pd.merge(ipsrnk, df, left_on="BilletId", right_on="загот")

    result.to_csv("result_general.csv")
