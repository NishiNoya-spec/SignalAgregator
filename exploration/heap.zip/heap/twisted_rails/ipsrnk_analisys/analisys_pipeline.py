import os
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from statsmodels.formula.api import ols

from exploration.twisted_rails.ipsrnk_analisys.constants import (
    PATH_TO_RESULT, TARGET)


@dataclass
class Analyser:
    data: pd.DataFrame

    def analyse(self):
        # self._preprocess_data()
        features = self._filter_features_by_p_value()
        return features

    def _preprocess_data(self):
        # self._preprocess_by_iqr()
        self._preprocess_data_by_zscore()

    def _preprocess_by_iqr(self):
        data_without_defect = self.data[self.data['дефект'] == 0]
        defect_data = self.data[self.data['дефект'] == 1]
        for column in data_without_defect.columns:
            if column != 'дефект' and column != 'billet_points' and column != 'last_point':
                q1 = np.percentile(data_without_defect[column], 1)
                q3 = np.percentile(data_without_defect[column], 99)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                data_without_defect = self._remove_outliers_iqr(
                    data_without_defect, column, lower_bound, upper_bound)

        self.data = pd.concat([data_without_defect, defect_data])

    @staticmethod
    def _remove_outliers_iqr(data_without_defect, column, lower_bound,
                             upper_bound):
        '''
        Метод для удаления выбросов по межквартильному расстоянию
        '''
        return data_without_defect[
            (data_without_defect[column] >= lower_bound)
            & (data_without_defect[column] <= upper_bound)]

    def _preprocess_data_by_zscore(self):
        data_transformed = self.data.copy()
        for column in self.data.columns:
            if column != TARGET and column != 'billet_points' and column != 'last_point':
                data_transformed[column] = stats.zscore(
                    data_transformed[column])
            if column != 'billet_points':
                data_transformed[column] = pd.to_numeric(
                    data_transformed[column])
        self.data = data_transformed

    def _filter_features_by_p_value(self, p_value_limit=0.01):
        formula = TARGET + "~" + " + ".join(
            list(self.data.drop([TARGET], axis=1).columns))
        model = ols(formula, data=self.data).fit()
        anove_table = sm.stats.anova_lm(model, typ=2)
        anove_table.to_csv(os.path.join(PATH_TO_RESULT, "anove_table.csv"),
                           sep=";",
                           decimal=",")
        good_features = list(
            anove_table[anove_table['PR(>F)'] > p_value_limit].index)
        return good_features


@dataclass
class CutCalculator:
    len_data: pd.DataFrame
    lot_data: pd.DataFrame
    cut_length: pd.DataFrame = field(init=False)

    def __post_init__(self):
        self.len_data["Zagot"] = (
            "Л2" + self.len_data["Плавка"].str.split("-", expand=True)[2] +
            self.len_data["Руч"].astype(str) + "0" +
            self.len_data["Заг"].astype(str) + "_" +
            len_data["Вр.проката"].dt.year.astype(str).str.split(
                ".", expand=True)[0])

        self.len_data = self.len_data.set_index("Zagot")
        self.lot_data["Zagot"] = (
            self.lot_data["Zagot"].str[:-1] + "_" +
            lot_data["dtBeginProkat"].dt.year.astype(str).str.split(
                ".", expand=True)[0])

        self.lot_data["crate"] = self.lot_data[
            "UniqueLotIDstring"].str.replace('\d+', '').str.replace(';', '')

        a_crate_cut_length_1, y_crate_cut_length_1 = self._get_cut_length_by_cut_data(
        )
        a_crate_cut_length_2, y_crate_cut_length_2 = self._get_cut_length_by_lot(
        )
        a_crate_cut_length = pd.concat(
            [a_crate_cut_length_1, a_crate_cut_length_2])
        y_crate_cut_length = pd.concat(
            [y_crate_cut_length_1, y_crate_cut_length_2])

        a_crate_cut_length = a_crate_cut_length.reset_index().drop_duplicates(
            subset=["index"], keep="first").set_index("index")
        y_crate_cut_length = y_crate_cut_length.reset_index().drop_duplicates(
            subset=["index"], keep="first").set_index("index")
        self.cut_length = pd.concat([a_crate_cut_length, y_crate_cut_length],
                                    axis=1).dropna()
        self.cut_length.columns = ["crate_A", "crate_Y"]
        self.cut_length.to_csv("cut_info.csv")

    def _get_cut_length_by_cut_data(self):
        a_crate_cut_length = self.len_data["Дл. ЛНК, мм"] - self.len_data[
            "Дл. СОС, мм"]
        y_crate_cut_length = self.len_data[
            "Дл. ЛНК, мм"] - a_crate_cut_length - 100000

        return a_crate_cut_length[(a_crate_cut_length <= 2000) & (a_crate_cut_length >= 700)], \
               y_crate_cut_length[(y_crate_cut_length <= 2000) & (y_crate_cut_length >= 700)]

    def _get_cut_length_by_lot(self):
        self.lot_data["crate"] = self.lot_data[
            "UniqueLotIDstring"].str.replace('\d+', '').str.replace(';', '')
        l_a = self.lot_data[self.lot_data["crate"] == "A"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "la"},
                axis="columns")["la"].str.replace(",", ".").astype(float)
        l_b = self.lot_data[self.lot_data["crate"] == "B"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "lb"},
                axis="columns")["lb"].str.replace(",", ".").astype(float)
        l_c = self.lot_data[self.lot_data["crate"] == "C"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "lc"},
                axis="columns")["lc"].str.replace(",", ".").astype(float)
        l_y = self.lot_data[self.lot_data["crate"] == "Y"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "ly"},
                axis="columns")["ly"].str.replace(",", ".").astype(float)
        l_ab = self.lot_data[self.lot_data["crate"] == "AB"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "lab"},
                axis="columns")["lab"].str.replace(",", ".").astype(float)
        l_cy = self.lot_data[self.lot_data["crate"] == "CY"].drop_duplicates(
            subset=["Zagot"],
            keep="first").set_index("Zagot").sort_index().rename(
                {"lenCOC100": "lyc"},
                axis="columns")["lyc"].str.replace(",", ".").astype(float)

        general = pd.concat([l_a, l_b, l_c, l_y, l_ab, l_cy], axis=1).dropna()

        a_crate_cut_length = 1000 * (general["lab"] - general["la"] -
                                     general["lb"])
        y_crate_cut_length = 1000 * (general["lyc"] - general["lc"] -
                                     general["ly"])
        return a_crate_cut_length[(a_crate_cut_length <= 2000) & (a_crate_cut_length >= 700)], \
               y_crate_cut_length[(y_crate_cut_length <= 2000) & (y_crate_cut_length >= 700)]


if __name__ == '__main__':
    len_data = pd.read_excel("StabMas.xlsx")
    lot_data = pd.concat(
        [pd.read_excel(f"lots{postfix}.xlsx") for postfix in ["", "_2"]])
    lot_data["dtBeginProkat"] = pd.to_datetime(lot_data["dtBeginProkat"])
    len_data["Вр.проката"] = pd.to_datetime(len_data["Вр.проката"])
    calculator = CutCalculator(len_data=len_data, lot_data=lot_data)
