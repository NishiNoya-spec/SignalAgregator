import pandas as pd
from catboost import CatBoostClassifier

from exploration.twisted_rails.ipsrnk_analisys.constants import (
    COLUMNS_TO_DROP, DATA_PATH)

if __name__ == "__main__":
    model = CatBoostClassifier()
    model.load_model('/path/to/model/model.cb')
    input_fetures = model.feature_names_
    cut_info = pd.read_csv(
        "path/to/test/data.csv",
    ).rename({"Unnamed: 0": "BilletId"}, axis="columns")

    filtered_data = cut_info[(cut_info["defect_crate"] == "A")]
    # filtered_data = mereged_data[(mereged_data["defect_crate"] == "Y")].drop_duplicates(keep="first")
    # filtered_data = mereged_data[(mereged_data["defect_crate"] != "Y") &
    # (mereged_data["defect_crate"] != "A")].drop_duplicates(keep="first")

    filtered_data["prediction"] = model.predict(filtered_data[input_fetures])
    accuracy = (filtered_data["prediction"] == filtered_data["дефект"]).mean()
    filtered_data[["BilletId", "дефект", "prediction"]].to_csv("result_A.csv",
                                                               sep=";",
                                                               decimal=",")
