DATA_PATH = '/path/to/result_general.csv'
TARGET = "дефект"
COLUMNS_TO_DROP = ["Unnamed: 0", "загот"]
PATH_TO_RESULT = "/path/to/result/folder"
MODEL_PARAMS = {
    "Linear": {},
    "CatBoost": {
        "iterations": 10000,
        "early_stopping_rounds": 10,
        "learning_rate": 0.1,
        "random_seed": 0,
        "depth": 4,
        'class_weight': 'balanced',
    },
    "RandomForest": {
        "random_seed": 0,
        "max_depth": 4,
    },
}
