from dataclasses import dataclass
from typing import List

import pandas as pd
from evraz.datascience import (CLASSIFICATION_MODELS, EDA, REGRESSION_MODELS,
                               TASK_TYPES, Experiment, ModelTrainer)
from imblearn.under_sampling import RandomUnderSampler

from exploration.twisted_rails.ipsrnk_analisys.constants import (MODEL_PARAMS,
                                                                 TARGET)


@dataclass
class Trainer:
    data: pd.DataFrame
    features: List[str]

    def train_classification(self, shufl_data=False):
        task_type = TASK_TYPES.CLASSIFICATION
        model_type = CLASSIFICATION_MODELS.CatBoost
        self._train(task_type, model_type, shufl_data=shufl_data)

    def train_regression(self, shufl_data=False):
        task_type = TASK_TYPES.REGRESSION
        model_type = REGRESSION_MODELS.CatBoost
        self._train(task_type, model_type, shufl_data=shufl_data)

    def _train(self, task_type, model_type, shufl_data):
        train_data = self.data.copy()
        if shufl_data:
            undersampler = RandomUnderSampler(sampling_strategy=0.5)
            X, y = undersampler.fit_resample(self.data.drop([TARGET], axis=1),
                                             self.data[TARGET])
            X[TARGET] = y
            train_data = X

        experiment = Experiment(
            EDA.Correlations,
            EDA.Histograms,
            EDA.DescribeFeatures,
            self.FeatureEngineering,
            ModelTrainer.TrainModel,
        )

        experiment.start(train_data.sample(frac=1).reset_index(
            drop=True)[self.features + [TARGET]],
                         task_type=task_type,
                         target=TARGET,
                         model_type=model_type,
                         model_params=MODEL_PARAMS[model_type.value],
                         run_name=TARGET,
                         min_periods=10)

    @staticmethod
    def FeatureEngineering(rails_inputs_and_outputs, *args, **kwargs):
        return rails_inputs_and_outputs.ffill().bfill(), None
