import pandas as pd
import numpy as np
from glob import glob
from datetime import datetime, timedelta
import pickle


def csv_to_parquet():
    dict_files = {}
    for source in ["TBK", "U0"]:
        files = []
        for filepath in glob("./data/" + source + "/*.csv"):
            if source == "U0":
                timestamp = filepath[filepath.find(source) + 3:filepath.find('_Л')]
                parq_folder = filepath[2:filepath.find(source) + 2] + '/parquet/'
                pos_list = [[0, 4], [4, 6], [6, 8], [8, 10], [10, 12], [12, 14]]
                df = pd.read_csv(filepath, sep=";", decimal=",")
            else:
                timestamp = filepath[filepath.find(source) + 4:filepath.find('.csv')]
                parq_folder = filepath[2:filepath.find(source) + 3] + '/parquet/'
                pos_list = [[6, 10], [3, 5], [0, 2], [11, 13], [14, 16], [17, 19]]
                df = pd.read_csv(filepath, encoding='iso-8859-1', skiprows=[0, 1, 2, 3, 4], sep=";", decimal=",")
            d_vals = {}

            for time_measure, pos in zip(['year', 'month', 'day', 'hour', 'minute', 'sec'], pos_list):
                d_vals[time_measure] = timestamp[pos[0]:pos[1]]

            parquet_filepath = d_vals['year'] + '-' + d_vals['month'] + '-' + d_vals['day'] + '_' + \
                               d_vals['hour'] + '-' + d_vals['minute'] + '-' + d_vals['sec']
            df.to_parquet(parq_folder + parquet_filepath + '.parquet')
            files.append({'timestamp': datetime.strptime(parquet_filepath, '%Y-%m-%d_%H-%M-%S'),
                          'filepath': filepath})
        dict_files[source] = files
    with open('data/files_tmpl.pickle', 'wb') as handle:
        pickle.dump(dict_files, handle, protocol=pickle.HIGHEST_PROTOCOL)


def read_parquet_data() -> dict:
    dict_files = {}
    for source in ["U0", "TBK"]:
        files = []
        for filepath in glob("./data/" + source + "/parquet/*.parquet"):
            data = pd.read_parquet(filepath)
            timestamp = filepath[filepath.find(source) + 11:filepath.find('.parquet')]
            files.append({'timestamp': timestamp,
                          'data': data})
        dict_files[source] = files
    return dict_files


if __name__ == '__main__':
    csv_to_parquet()
    files = read_parquet_data()

    data_comp, founded_tbk, founded_u0 = [], [], []

    # Привязываем первый возможный файл ТВК
    u0_first_idx = 0
    first_comp_founded = False
    while True:
        tbk_first_idx = 0
        while True:
            files_delta = (files['TBK'][tbk_first_idx]['timestamp'] -
                           files['U0'][u0_first_idx]['timestamp']).total_seconds()
            # Обнаружен подходящий ТВК файл для привязки
            if 60 < files_delta < 180:
                founded_tbk.append(tbk_first_idx)
                founded_u0.append(u0_first_idx)
                data_comp.append({'U0_index': u0_first_idx,
                                  'U0_datetime': datetime.strftime(files['U0'][u0_first_idx]['timestamp'],
                                                                   '%d.%m.%Y %H:%M:%S'),
                                  'U0_delta': '-',
                                  'TBK_index': tbk_first_idx,
                                  'TBK_datetime': datetime.strftime(files['TBK'][tbk_first_idx]['timestamp'],
                                                                    '%d.%m.%Y %H:%M:%S'),
                                  'TBK_delta': '-',
                                  'Files_delta': files_delta,
                                  'status': 'Дельты по последовательным U0 и TBK невозможно проверить. '
                                            'Дельта между файлами ТВК и U0 не превышает 200 секунд',
                                  'связываем': True})
                first_comp_founded = True
                break
            elif 60 >= files_delta:
                tbk_first_idx += 1
            else:
                break
        if first_comp_founded:
            break
        else:
            data_comp.append({'U0_index': u0_first_idx,
                              'U0_datetime': datetime.strftime(files['U0'][u0_first_idx]['timestamp'],
                                                               '%d.%m.%Y %H:%M:%S'),
                              'U0_delta': '-',
                              'TBK_index': 'Не найден',
                              'TBK_datetime': '-',
                              'TBK_delta': '-',
                              'Files_delta': '-',
                              'status': 'Подходящий ТВК файл не обнаружен.',
                              'связываем': False})
            u0_first_idx += 1

    # Запускаем последовательную привязку остальных файлов
    for u0_idx in range(founded_u0[-1] + 1, len(files['U0']) - founded_u0[-1]):
        if u0_idx == 911:
            a = 1
        u0_delta = (files['U0'][u0_idx]['timestamp'] -
                    files['U0'][founded_u0[-1]]['timestamp']).total_seconds()
        last_files_delta = (files['TBK'][founded_tbk[-1]]['timestamp'] -
                            files['U0'][founded_u0[-1]]['timestamp']).total_seconds()

        sorted_fun = lambda i: \
            abs((files['TBK'][i]['timestamp'] - files['U0'][u0_idx]['timestamp']).total_seconds() - last_files_delta) \
            if abs((files['TBK'][i]['timestamp'] - files['U0'][u0_idx]['timestamp']).total_seconds() -
                   last_files_delta) < 120 \
            else np.inf

        sorted_fun = lambda i: \
            abs((files['TBK'][i]['timestamp'] - files['TBK'][founded_tbk[-1]]['timestamp']).total_seconds() - u0_delta)\
            if abs((files['TBK'][i]['timestamp'] - files['TBK'][founded_tbk[-1]]['timestamp']).total_seconds() -
                   u0_delta) < 60 \
            else np.inf

        tbk_idxs = sorted(range(founded_tbk[-1] + 1, len(files['TBK'])), key=sorted_fun)
        if tbk_idxs:
            tbk_idx = tbk_idxs[0]
        else:
            data_comp.append({'U0_index': u0_idx,
                              'U0_datetime': datetime.strftime(files['U0'][u0_idx]['timestamp'],
                                                               '%d.%m.%Y %H:%M:%S'),
                              'U0_delta': u0_delta,
                              'TBK_index': 'Не найден',
                              'TBK_datetime': '-',
                              'TBK_delta': '-',
                              'Files_delta': '-',
                              'status': 'Подходящий ТВК файл не обнаружен.',
                              'связываем': False})
            continue

        tbk_delta = (files['TBK'][tbk_idx]['timestamp'] -
                     files['TBK'][founded_tbk[-1]]['timestamp']).total_seconds()
        files_delta = (files['TBK'][tbk_idx]['timestamp'] - files['U0'][u0_idx]['timestamp']).total_seconds()

        # Подходящее по всем параметрам решение
        if tbk_delta > 600 and u0_delta > 600:
            max_delta = 60
        elif tbk_delta > 300 and u0_delta > 300:
            max_delta = 40
        else:
            max_delta = 20
        if abs(tbk_delta - u0_delta) < max_delta and abs(files_delta - last_files_delta) < 120:
            founded_tbk.append(tbk_idx)
            founded_u0.append(u0_idx)
            data_comp.append({'U0_index': u0_idx,
                              'U0_datetime': datetime.strftime(files['U0'][u0_idx]['timestamp'],
                                                               '%d.%m.%Y %H:%M:%S'),
                              'U0_delta': u0_delta,
                              'TBK_index': tbk_idx,
                              'TBK_datetime': datetime.strftime(files['TBK'][tbk_idx]['timestamp'],
                                                                '%d.%m.%Y %H:%M:%S'),
                              'TBK_delta': tbk_delta,
                              'Files_delta': files_delta,
                              'status': 'Дельты по последовательным U0 и TBK ~равны. '
                                        'Дельта между файлами ТВК и U0 не превышает 200 секунд',
                              'связываем': True})
            continue
        # Возможно, подходящее решение, но произошел скачок серверного времени ТВК
        elif abs(tbk_delta - u0_delta) >= max_delta and abs(files_delta - last_files_delta) < 100:
            last_tbk_delta = (files['TBK'][founded_tbk[-1]]['timestamp'] -
                              files['TBK'][founded_tbk[-2]]['timestamp']).total_seconds()
            last_u0_delta = (files['U0'][founded_u0[-1]]['timestamp'] -
                             files['U0'][founded_u0[-2]]['timestamp']).total_seconds()
            tbk_deltachange = abs(last_tbk_delta - tbk_delta)
            u0_deltachange = abs(last_u0_delta - u0_delta)
            files_deltachange = abs(files_delta - last_files_delta)
            if abs(files_deltachange - max(tbk_deltachange, u0_deltachange)) < 10:
                founded_tbk.append(tbk_idx)
                founded_u0.append(u0_idx)
                data_comp.append({'U0_index': u0_idx,
                                  'U0_datetime': datetime.strftime(files['U0'][u0_idx]['timestamp'],
                                                                   '%d.%m.%Y %H:%M:%S'),
                                  'U0_delta': u0_delta,
                                  'TBK_index': tbk_idx,
                                  'TBK_datetime': datetime.strftime(files['TBK'][tbk_idx]['timestamp'],
                                                                    '%d.%m.%Y %H:%M:%S'),
                                  'TBK_delta': tbk_delta,
                                  'Files_delta': files_delta,
                                  'status': 'Дельты по последовательным U0 и TBK ~равны. '
                                            'Дельта между файлами ТВК и U0 не превышает 200 секунд. '
                                            'Похоже, произошел скачок серверного времени',
                                  'связываем': True})
                continue
        # Подходящего решения не нашлось
        data_comp.append({'U0_index': u0_idx,
                          'U0_datetime': datetime.strftime(files['U0'][u0_idx]['timestamp'],
                                                           '%d.%m.%Y %H:%M:%S'),
                          'U0_delta': u0_delta,
                          'TBK_index': 'Не найден',
                          'TBK_datetime': '-',
                          'TBK_delta': '-',
                          'Files_delta': '-',
                          'status': 'Подходящий ТВК файл не обнаружен.',
                          'связываем': False})

    comp_df = pd.DataFrame.from_dict(data_comp)
    comp_df.to_excel('data/TBK_U0_compilation.xlsx')
