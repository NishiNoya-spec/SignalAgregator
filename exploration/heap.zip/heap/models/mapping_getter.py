import os
from exploration.experiments_aggregation import data_mapping, dto


def get_mapping():
    constants = dto.Constants(
        PATH_TO_RESULT="",
        NUM_OF_CORES=1,

        DATA_PATHS={
            "LNK100": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                     key_folder="ipsrnk",
                                     nested_folders="rail_points_files",
                                     filename_key=""),

            "TBK": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                     key_folder="tbk",
                                     nested_folders="file_details",
                                     filename_key=""),

            "U0": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                    key_folder="U0",
                                    nested_folders="rollings_points_files", filename_key=""),

            "TDM_UF_1": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UF",
                                          nested_folders="rollings_points_files", filename_key="_UF_1"),
            "TDM_UF_2": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UF",
                                          nested_folders="rollings_points_files", filename_key="_UF_2"),
            "TDM_UF_3": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UF",
                                          nested_folders="rollings_points_files", filename_key="_UF_3"),

            "TDM_UR_1": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UR",
                                          nested_folders="rollings_points_files", filename_key="_UR_1"),
            "TDM_UR_2": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UR",
                                          nested_folders="rollings_points_files", filename_key="_UR_2"),
            "TDM_UR_3": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                          key_folder="UR",
                                          nested_folders="rollings_points_files", filename_key="_UR_3"),
            "TDM_E_1": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                         key_folder="E",
                                         nested_folders="rollings_points_files", filename_key="_E_1",
                                         ),
            "TDM_E_2": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                         key_folder="E",
                                         nested_folders="rollings_points_files", filename_key="_E_2",
                                         ),
            "TDM_E_3": dto.RecursivePath(main_folder=r"\\ZSMK-9684-001\Data\2023",
                                         key_folder="E",
                                         nested_folders="rollings_points_files", filename_key="_E_3",
                                         ),

        },
        DATA_TYPES={  # c первого мая по текущее число
            "LNK100": "target",
            "TBK": "features",
            "U0": "features",
            "TDM_UF_1": "features",
            "TDM_UF_2": "features",
            "TDM_UF_3": "features",
            "TDM_E_1": "features",
            "TDM_E_2": "features",
            "TDM_E_3": "features",
            "TDM_UR_1": "features",
            "TDM_UR_2": "features",
            "TDM_UR_3": "features",
        },

        AGGREGATION=dto.Aggregation(target_segments=[[0, 3]],
                                    target_measurement="abs",
                                    target_inner_method=["all", None],
                                    features_segments=[[0, 3]],
                                    features_measurement="abs",
                                    features_inner_method=["all", None],
                                    main_method="one-to-one"),
        MARK_FILTER=True,
        INTERPOLATE=True,
        MARK='Э76ХФ',
        PATH_TO_METADATA=os.path.join(r'\\ZSMK-9684-001\Data\DS\metadata\meta_2307_3007*.xlsx'),
        BILLET_ID="BilletId",
        BILLET_POINT="billet_points",
        FEATURES_TO_DROP=[
            'speed',
            'u0.descaling.pressure.extrapolated',
            'moment',
            'Unnamed: 0',
        ],
        TARGETS=["Torsion"],
        FORBIDDEN_FEATURES=[
            "Time",
            "moment",
            "BilletId",
            "billet_points",
            "BilletPoints",
            "BilletPoint",
        ],
        TARGET_AGG_METHODS=[]
        ,
        FEATURES_AGG_METHODS=[],
    )
    mapping_creator = data_mapping.MappingCreator(constants=constants)
    metadata = mapping_creator.get_metadata()
    mapping = mapping_creator.create_mapping(metadata=metadata)
    return mapping

