from glob import glob

import pandas as pd
from evraz.datascience import (EDA, REGRESSION_MODELS, CLASSIFICATION_MODELS, TASK_TYPES, Experiment,
                               ModelTrainer)
import os
from feature_engine.selection import DropCorrelatedFeatures
from tqdm import tqdm

PATH_TO_DATA = r'\\ZSMK-9684-001\Data\DS\processed_first_3m'
MAIN_DATA_NAME_PATTERN = 'crate_A*.csv'
EXTRA_TBK_DATA_NAME_PATTERN = 'af_data_processed*.csv'
EXTRA_E_3_DATA_NAME_PATTERN = 'tdm_e_3_processed*.csv'
EXTRA_UR_3_DATA_NAME_PATTERN = 'tdm_ur_3_processed*.csv'
TARGET_DATA_NAME_PATTERN = 'target_0_3*.csv'

AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_DEFAULT_REGION = os.getenv("AWS_DEFAULT_REGION")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
MLFLOW_S3_ENDPOINT_URL = os.getenv("MLFLOW_S3_ENDPOINT_URL")
MLFLOW_URL = os.getenv("MLFLOW_URL")
PROJECT_NAME = os.getenv("PROJECT_NAME")
COMMIT_HASH = os.getenv("COMMIT_HASH")

TARGET = "LNK100_Torsion_min"
# TARGET = "LNK100_Torsion_mean"
# TARGET = "LNK100_abs_Torsion_tg"

TARGET_CLASSIFICATION_LIMIT = -500
# TARGET_CLASSIFICATION_LIMIT = 180
# TARGET_CLASSIFICATION_LIMIT = 65

BILLET_ID = "BilletId"
BILLET_POINTS = "billet_points"
EMPTY_COL = "Unnamed: 0"
TARGET_PREFIX = "LNK"

model_params = {
    "CatBoost": {
        "iterations": 10000,
        "early_stopping_rounds": 10,
        "learning_rate": 0.1,
        "random_seed": 0,
        "depth": 4,
        "scale_pos_weight": 2,
     "l2_leaf_reg": 10,

    },
}


def FeatureEngineering(rails_inputs_and_outputs, *args, **kwargs):
    return rails_inputs_and_outputs.ffill().bfill(), None


def get_data(path: str, extra_data: bool):
    paths = glob(path)
    data = []

    for path in tqdm(paths):
        part_data = pd.read_csv(path)
        part_data[BILLET_ID] = part_data[BILLET_ID].str.split("_", expand=True)[0]
        data.append(part_data)

    data = pd.concat(data)
    if extra_data:
        columns_to_drop = [EMPTY_COL]
    else:
        columns_to_drop = [BILLET_POINTS, EMPTY_COL] + [col for col in data.columns if TARGET_PREFIX in col]

    data = data.drop(columns=columns_to_drop)
    use_columns = [BILLET_ID] + get_use_columns(data)
    return data[use_columns]


def get_use_columns(data):
    use_columns = []
    for col in data.columns[2:]:
        if len(data[col].dropna()) > 0 and data[col].std() > 0.00001:
            if len(data[col]) / len(data[col].dropna()) < 1.15:
                use_columns.append(col)
    return use_columns


def clean_by_quantile(data):
    for col in data.columns:
        if col not in [TARGET, BILLET_ID]:
            quantile_01 = data[col].quantile(0.005)
            quantile_99 = data[col].quantile(0.995)
            data = data[(data[col] >= quantile_01) & (data[col] <= quantile_99)]
    return data


def get_target_data(path_to_data):
    paths = glob(path_to_data)
    target_data = list()
    for path in paths:
        target_data.append(pd.read_csv(path, usecols=[BILLET_ID, TARGET]))

    target_data = pd.concat(target_data)
    target_data[BILLET_ID] = target_data[BILLET_ID].str.split("_", expand=True)[0]
    return target_data


def process(clean_data=False):

    target_data = get_target_data(os.path.join(PATH_TO_DATA, TARGET_DATA_NAME_PATTERN))
    all_data = get_data(os.path.join(PATH_TO_DATA, MAIN_DATA_NAME_PATTERN), extra_data=False)
    af_data = get_data(os.path.join(PATH_TO_DATA, EXTRA_TBK_DATA_NAME_PATTERN), extra_data=True,)
    tdm_e_3_data = get_data(os.path.join(PATH_TO_DATA, EXTRA_E_3_DATA_NAME_PATTERN), extra_data=True,)
    tdm_ur_3_data = get_data(os.path.join(PATH_TO_DATA, EXTRA_UR_3_DATA_NAME_PATTERN), extra_data=True,)

    all_data = pd.merge(all_data, af_data, on=BILLET_ID)
    all_data = pd.merge(all_data, tdm_e_3_data, on=BILLET_ID)
    all_data = pd.merge(all_data, tdm_ur_3_data, on=BILLET_ID)
    all_data = pd.merge(target_data, all_data, on=BILLET_ID)

    del af_data
    del tdm_e_3_data
    del tdm_ur_3_data
    del target_data

    #TARGET Torsion_min
    use_columns = [TARGET, BILLET_ID, 'TBK_aF_tg', "TDM_UR_1_ur.axial_displace_lower_shaft_min", "TDM_E_1_e.uf.os.load_hor_roll.upper_min",
                   "aF_tg_1_to_5.5", "TBK_aF_std", "U0_u0.ds.load_vert_roll_mean", "aF_std_1_to_5.5",
                   "E_3_e.uf.load_hor_roll_mean_3.4_to_3.9", "asM_tg_0.29_to_1", #"tpz_c4",
                   "E_3_e.uf.axial_displace_lower_shaft_std_9.5_to_20", "U0_u0.gr242_1.table_pos_after_min",
                   "U0_u0.axial_displace_lower_shaft_min", "tMO_std_0.29_to_1", "U0_u0.gr212_1.ds.table_pos_before_min",
                   "U0_u0.ds.pos_vert_roll_in_min", "TDM_UF_2_uf.ds.pos_up_hor_roll_min", "TDM_UF_2_uf.os.pos_up_hor_roll_min",
                   "U0_u0.ds.pos_vert_roll_out_min", "TDM_UF_2_uf.ds.pos_up_hor_roll_max", "TDM_UF_2_uf.os.pos_up_hor_roll_max",
                   "U0_u0.ds.pos_vert_roll_out_max", "TDM_E_2_e.ur.axial_displace_lower_shaft_min", "TDM_E_2_e.speed.set_min",
                   "U0_u0.gr232_2.ds.table_pos_after_min", "U0_u0.gr232_2.os.table_pos_after_min", "U0_u0.gr232_2.ds.table_pos_after_max",
                   "U0_u0.gr232_2.os.table_pos_after_max", "TDM_E_2_e.ur.axial_displace_lower_shaft_std", "TDM_UF_3_uf.os.load_vert_roll_mean",
                   "TDM_UF_1_uf.ge25-1.os.jackhammer_pos.act_min", "TDM_E_1_e.torque_min", "TDM_UF_1_uf.ge22-1.os.line_after.act_min",
                   "TDM_UR_1_ur.gr22-1.os.table_pos_before.act_min", "TDM_UF_2_uf.ds.load_hor_roll.upper_max",
                   "TBK_aF_min", "TDM_E_2_e.torque_std", "E_3_e.uf.ds.load_vert_roll_diff_max_min_5.8_to_7.1"
                   ]
    #  TARGET Torsion_mean
    # use_columns = [TARGET, BILLET_ID, 'aF_tg_1_to_5.5', 'U0_u0.gr242_1.table_pos_after_min', 'TDM_UR_1_ur.os.load_vert_roll_max',
    #                 'TBK_aF_min', 'U0_u0.ds.pos_low_hor_roll_min', 'aF_max_9.6_to_25',
    #                'TDM_UF_3_uf.ds.pos_low_hor_roll_std', 'TDM_UR_3_ur.os.load_vert_roll_diff_max_min', 'TBK_aF_std',
    #                'TDM_UR_3_ur.ds.load_hor_roll.upper_std', 'TDM_UR_3_ur.os.load_vert_roll_mean', 'U0_u0.gr212_1.ds.table_pos_before_min',
    #                'TDM_E_3_e.ur.os.load_hor_roll.upper_std', 'TDM_E_1_e.ur.os.load_hor_roll.lower_std',
    #                'TDM_UR_1_ur.gr22-1.os.table_pos_before.act_min', 'TDM_UR_2_ur.ge11-3.ds.line_before.act_min',
    #                'TDM_E_1_e.ur.ds.load_hor_roll.upper_std', 'TDM_UF_1_uf.ds.pos_vert_roll_in_min',
    #                ]
    #  TARGET Torsion_abs_tg
    # use_columns = [TARGET, BILLET_ID,  'TDM_UR_1_ur.ds.pos_vert_roll_in_min', 'U0_u0.ds.pos_vert_roll_in_min',
    #                'TDM_UF_3_uf.load_hor_roll_mean', 'TDM_E_1_e.ds.pos_low_hor_roll_min', 'aF_tg_1_to_5.5',
    #                'TDM_UF_1_uf.ds.pos_vert_roll_in_min', 'TBK_tMO_mean', 'U0_u0.axial_displace_lower_shaft_min',
    #                'ccF_tg_1_to_5.5', 'asF_std_1_to_5.5', 'TDM_UR_2_ur.gr24_bt01.temp.extrapolated_max',
    #                'TDM_E_2_e.torque_std', 'TDM_E_1_e.ds.pos_up_hor_roll_min',
    #                'TBK_aF_min', 'tM2_tg_5.5_to_6.6', 'TDM_UR_3_ur.os.load_vert_roll_mean',
    #                'TDM_UF_1_uf.axial_displace_lower_shaft_min', 'TDM_UR_3_ur.ds.load_hor_roll.upper_std',
    #                'TDM_UR_3_ur.os.load_vert_roll_diff_max_min', 'TDM_UR_1_ur.ds.pos_low_hor_roll_min',
    #                'TDM_UR_1_ur.load_hor_roll_min', 'TBK_wH_mean', 'TBK_aF_std', 'TDM_UF_1_uf.ds.pos_vert_roll_in_std',
    #                'h_tg_5.5_to_6.6', 'wF_tg_6.6_to_9.6', 'U0_u0.os.pos_vert_roll_in_min', 'TBK_tF_max',
    #                ]

    all_data = all_data[use_columns]
    dcf = DropCorrelatedFeatures(threshold=0.7, )
    data_target = all_data[TARGET].copy()
    all_data = dcf.fit_transform(X=all_data.drop([TARGET], axis=1), y=all_data[TARGET])
    all_data[TARGET] = data_target

    if clean_data:
        all_data = clean_by_quantile(all_data)

    all_data.to_csv(f"for_{TARGET}.csv", index=False)
    return all_data


def get_model(process_data=True, classification_model=True):
    if process_data:
        all_data = process().set_index(BILLET_ID)
    else:
        all_data = pd.read_csv(f"for_{TARGET}.csv").set_index(BILLET_ID)

    for classification_model in [False, True]:
        if classification_model:
            all_data[TARGET] = (all_data[TARGET] <= TARGET_CLASSIFICATION_LIMIT).astype(int)
            model_types = [CLASSIFICATION_MODELS.CatBoost]
            task_type = TASK_TYPES.CLASSIFICATION
        else:
            model_types = [REGRESSION_MODELS.CatBoost]
            task_type = TASK_TYPES.REGRESSION

        all_data = all_data.sample(frac=1)

        experiment = Experiment(
            EDA.Correlations,
            EDA.Histograms,
            EDA.DescribeFeatures,
            FeatureEngineering,
            ModelTrainer.TrainModel,
        )

        for model_type in model_types:
            experiment.start(all_data,
                             task_type=task_type,
                             target=TARGET,
                             model_type=model_type,
                             model_params=model_params[model_type.value],
                             run_name=TARGET,
                             corr_min_periods=100)


if __name__ == "__main__":
    get_model()
