import os
from datetime import datetime
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import shap
from catboost import CatBoostClassifier, CatBoostRegressor
from evraz.classic.app import DTO
from tqdm import tqdm

from exploration.experiments_aggregation.aggregator import AggregationFactory
from exploration.models.constants import (BILLET_POINT, IMPORTANT_FEATURES,
                                          MODEL_TYPE, PATH_TO_MODEL, RAIL_LEN,
                                          RESULT_COL_NAME, USE_COLUMNS)
from exploration.models.mapping_getter import get_mapping


class Features(DTO):
    """
    Описание сигналов: необходимых для функциорнирования модели:
    Передаются первые 5 метров с указанием длины заготовки
    """
    """имя сигнала: значения сигнала"""
    values: Dict[str, List[float]]


class Aggregates(DTO):
    """
    Описание фичей относительно агрегатов
    key: Агрегат_проход (Прим. TDM_UF_2)
    value: обязательно содержит billet_points в Features
    """
    aggregates: Dict[str, Features]


class Model:

    def __init__(self, model_type: str):
        self.model_type = model_type
        self.model = self._get_model()
        self.input_features = self.model.feature_names_
        self.aggregators = AggregationFactory()
        self.explainer = shap.Explainer(self.model)

    def _get_model(self):
        if self.model_type == "classification":
            model = CatBoostClassifier()
        else:
            model = CatBoostRegressor()

        model.load_model(PATH_TO_MODEL)
        return model

    def predict(self, aggregates: Aggregates, billet_id: str,
                rolling_time: datetime) -> Tuple[float, List[str]]:

        try:
            features = pd.DataFrame(self._get_features(aggregates))
        except:
            return pd.DataFrame({
                "time": [rolling_time],
                "BilletId": [billet_id],
                RESULT_COL_NAME: ["ошибка в данных"]
            })

        if len(features.dropna()) < len(features):
            return pd.DataFrame({
                "time": [rolling_time],
                "BilletId": [billet_id],
                RESULT_COL_NAME: ["ошибка в данных"]
            })

        num_signals = 7

        tips = {True: "Изменить значение", False: ""}

        columns = []

        for i in range(num_signals):
            columns.extend([f"sig{i}_impact", f"sig{i}_value", f"sig{i}_tips"])

        shap_values = self.explainer.shap_values(features)
        data_frame = pd.DataFrame(shap_values[0].T, columns=["impact"])
        data_frame["name"] = self.input_features
        # data_frame["negative_impact"] = data_frame["impact"].abs()
        # data_frame = data_frame.sort_values("negative_impact", ascending=False).reset_index(drop=True)
        signals = pd.concat([
            IMPORTANT_FEATURES.T, data_frame[["impact", "name"
                                              ]].set_index("name")
        ],
                            axis=1)  # .to_dict()["impact"]
        signals = signals[signals[0] < num_signals].drop(columns=[0])
        result_table = pd.concat(
            [signals, features.T.rename(columns={0: "value"})],
            axis=1).dropna()
        result_table["tip"] = (result_table["impact"] > 0).map(tips)
        result_table = result_table.to_numpy().flatten()
        result_table = pd.DataFrame(
            {col: [result_table[i]]
             for i, col in enumerate(columns)})
        if self.model_type == "classification":
            result_table[RESULT_COL_NAME] = self.model.predict_proba(features)[
                0, 1]
        else:
            result_table[RESULT_COL_NAME] = self.model.predict(features)[0]
        result_table["BilletId"] = billet_id
        result_table["time"] = rolling_time
        return result_table[["time", "BilletId", RESULT_COL_NAME] + columns]

    def _get_features(self, aggregates: Aggregates):
        features = list()
        old_features = list()
        for aggregate, data in aggregates.aggregates.items():
            data = pd.DataFrame(data.values)
            old_data = data.copy()
            data[BILLET_POINT] = self._update_coordinates(data[BILLET_POINT])
            data = data.set_index(BILLET_POINT)
            old_data = old_data.set_index(BILLET_POINT)
            data = data[~data.index.duplicated(keep='first')]
            old_data = old_data[~old_data.index.duplicated(keep='first')]
            data.columns = [f"{aggregate}_{col}" for col in data.columns]
            old_data.columns = [
                f"{aggregate}_{col}" for col in old_data.columns
            ]
            features.append(data)
            old_features.append(old_data)
        features = pd.concat(features, axis=1)
        old_features = pd.concat(old_features, axis=1)
        return self._calculate_features(features, old_features)

    def _update_coordinates(self, data):
        return data * RAIL_LEN / data.max()

    def _calculate_features(self, data, old_data):
        """Расчет всех фичей ниже производится на основе данных первых 3 метров.
    Перед взятием агрегаций первых 3 метров необходимо привести заготовки на всех проходах к единой длине.
    """

        input_features = dict()
        for input_feature in self.input_features:
            using_data = data
            features_names = input_feature.split("_div_")

            aggregator = "_"
            for agg_method in AGG_METHODS:
                if agg_method in features_names[-1]:
                    features_names[-1] = features_names[-1].replace(
                        agg_method, "")
                    if agg_method == "_diff":
                        aggregator = "_diff_max_min"
                    else:
                        aggregator = agg_method

            start = START_POINT
            end = END_POINT
            if "_to_" in features_names[0]:
                using_data = old_data
                first_part, second_part = features_names[0].split("_to_")
                start = float(first_part.split("_")[-1])
                end = float(second_part.split("_")[0])
                signal_name = first_part.split("_")[:-1]
                aggregate_name = ["TBK"]
                if "E" in signal_name and "3" in signal_name:
                    aggregate_name = ["TDM"]
                elif "UR" in signal_name and "3" in signal_name:
                    aggregate_name = ["TDM"]

                features_names[0] = "_".join(aggregate_name + signal_name)

            features = using_data[features_names[0]]
            if len(features_names) == 2:
                for drop_str in SUBSTR_TO_DROP:
                    if drop_str in features_names[0]:
                        features_names[1] = drop_str + features_names[1]

                features = (using_data[features_names[0]] /
                            using_data[features_names[1]]).dropna()

            if aggregator[1:] == "tg":
                input_features[input_feature] = [
                    self.aggregators.agg_by_method(
                        features[start:end].bfill().ffill(),
                        aggregator[1:],
                        points=np.array(features[start:end].index),
                    )
                ]
            else:
                input_features[input_feature] = [
                    self.aggregators.agg_by_method(features[start:end],
                                                   aggregator[1:])
                ]

        return input_features


if __name__ == "__main__":

    model = Model(MODEL_TYPE)

    retro_billets_map = get_mapping()

    predictions = []

    for billet_id, billet_map in tqdm(retro_billets_map.items()):
        aggregates = Aggregates(aggregates=dict())
        start_rolling_time = ""

        for aggregate, file_path in billet_map.items():

            usecols = USE_COLUMNS.get(aggregate, [])
            if aggregate == "TDM_UR_1":
                start_rolling_time = datetime.strptime(
                    os.path.split(file_path)[-1].split("_")[0], '%Y%m%d%H%M%S')

            if len(usecols) > 0:
                data = pd.read_csv(
                    file_path, sep=";", decimal=",", usecols=usecols).rename(
                        columns={'BilletPoints': 'billet_points'})
                aggregates.aggregates[aggregate] = Features(
                    values=data.to_dict(orient='list'))

        predictions.append(
            model.predict(aggregates, billet_id, start_rolling_time))

    pd.concat(predictions).to_csv("after_gaz_pause.csv",
                                  sep=";",
                                  decimal=",",
                                  encoding="windows=1251")
