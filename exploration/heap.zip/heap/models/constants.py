import pandas as pd

BILLET_POINT = "billet_points"
RAIL_LEN = 103
PATH_TO_MODEL = r'\\ZSMK-9684-001\Data\DS\models\model_min_03m_classification.cb'
START_POINT = 0
END_POINT = 3
STEP = 3
SUBSTR_TO_DROP = [
    "LNK_100_", "TBK_", "U0_", "TDM_UF_1_", "TDM_UF_2_", "TDM_UF_3_",
    "TDM_UR_1_", "TDM_UR_2_", "TDM_UR_3_", "TDM_E_1_", "TDM_E_2_", "TDM_E_3_"
]

AGG_METHODS = [
    "_max",
    "_min",
    "_mean",
    "_std",
    "_tg",
    "_diff",
]

MODEL_TYPE = "classification"
RESULT_COL_NAME = "prediction"

IMPORTANT_FEATURES = pd.DataFrame({
    "TDM_UR_1_ur.axial_displace_lower_shaft_min": [0],
    "TBK_aF_tg": [1],
    "aF_tg_1_to_5.5": [2],
    "tMO_std_0.29_to_1": [3],
    "TDM_E_1_e.uf.os.load_hor_roll.upper_min": [4],
    "TBK_aF_min": [5],
    "U0_u0.ds.load_vert_roll_mean": [6],
    "aF_std_1_to_5.5": [7],
    "TDM_UF_2_uf.ds.load_hor_roll.upper_max": [8],
    "U0_u0.gr242_1.table_pos_after_min": [9],
})

USE_COLUMNS = {
    "TBK": [
        'BilletPoints',
        "aF",
        "tMO",
        "asM",
    ],
    "U0": [
        'billet_points',
        "u0.ds.load_vert_roll",
        "u0.gr242_1.table_pos_after",
        "u0.axial_displace_lower_shaft",
        "u0.gr212_1.ds.table_pos_before",
        "u0.ds.pos_vert_roll_in",
        "u0.ds.pos_vert_roll_out",
        "u0.gr232_2.ds.table_pos_after",
        "u0.gr232_2.os.table_pos_after",
        "u0.ds.load_vert_roll",
        'u0.ds.pos_low_hor_roll',
    ],
    "TDM_UF_1": [
        'billet_points',
        "uf.ge25-1.os.jackhammer_pos.act",
        "uf.ge22-1.os.line_after.act",
    ],
    "TDM_UF_2": [
        'billet_points',
        "uf.ds.pos_up_hor_roll",
        "uf.os.pos_up_hor_roll",
        "uf.ds.load_hor_roll.upper",
    ],
    "TDM_UF_3": [
        'billet_points',
        "uf.os.load_vert_roll",
    ],
    "TDM_UR_1": [
        'billet_points',
        "ur.axial_displace_lower_shaft",
        "ur.gr22-1.os.table_pos_before.act",
    ],
    "TDM_UR_2": [
        'billet_points',
        "ur.gr22-1.os.table_pos_before.set",
        "ur.ge12-3.os.line_before.set",
    ],
    "TDM_UR_3": [
        'billet_points',
        "ur.os.load_vert_roll",
        "ur.os.pos_vert_roll_in",
        "ur.current",
        "ur.speed.act",
        "ur.os.load_hor_roll.upper",
    ],
    "TDM_E_1": [
        'billet_points',
        "e.uf.os.load_hor_roll.upper",
        "e.torque",
    ],
    "TDM_E_2": [
        'billet_points',
        "e.ur.axial_displace_lower_shaft",
        "e.speed.set",
        "e.ur.axial_displace_lower_shaft",
        "e.torque",
    ],
    "TDM_E_3": [
        'billet_points', "e.uf.load_hor_roll",
        "e.uf.axial_displace_lower_shaft", 'e.uf.ds.load_vert_roll'
    ],
}
