from typing import Dict, List, Tuple

import pandas as pd
import shap
from catboost import CatBoostClassifier
from evraz.classic.app import DTO

from exploration.experiments_aggregation.aggregator import AggregationFactory

BILLET_POINT = "billet_points"
RAIL_LEN = 103
PATH_TO_MODEL = r'model.cb'
START_POINT = 0
END_POINT = 3
STEP = 3
SUBSTR_TO_DROP = [
    "LNK_100_", "TBK_", "U0_", "TDM_UF_1_", "TDM_UF_2_", "TDM_UF_3_",
    "TDM_UR_1_", "TDM_UR_2_", "TDM_UR_3_", "TDM_E_1_", "TDM_E_2_", "TDM_E_3_"
]

AGG_METHODS = [
    "_max",
    "_min",
    "_mean",
    "_std",
    "_tg",
    "_diff_max_min",
]


class Features(DTO):
    """
    Описание сигналов: необходимых для функциорнирования модели:
    Пример для модели классификации по -600 мкм:
    - u0.ds.pos_vert_roll_in
    - u0.ds.pos_vert_roll_out
    - uf.ds.load_hor_roll.upper (второй проход)
    - uf.axial_displace_lower_shaft (второй проход)
    - uf.os.pos_up_hor_roll (третий проход)
    - uf.os.pos_low_hor_roll (третий проход)
    - uf.ds.load_vert_roll (третий проход)
    - uf.ds.pos_low_hor_roll (третий проход)
    - uf.axial_displace_lower_shaft (третий проход)
    - ur.ds.pos_vert_roll_in (второй проход)
    - ur.ds.pos_vert_roll_out (второй проход)
    - ur.gr27-1.table_pos_before.set (третий проход)
    - ur.ge11-3.ds.line_before.set (третий проход)
    - e.ur.axial_displace_lower_shaft (второй проход)
    - aF (данные TBK)
    Передаются первые 5 метров с указанием длины заготовки
    """
    """имя сигнала: значения сигнала"""
    values: Dict[str, List[float]]


class Aggregates(DTO):
    """
    Описание фичей относительно агрегатов
    key: Агрегат_проход (Прим. TDM_UF_2)
    value: обязательно содержит billet_points в Features
    """
    aggregates: Dict[str, Features]


class Model:

    def __init__(self):
        self.model = self._get_model()
        self.input_features = self.model.feature_names_
        self.aggregators = AggregationFactory()
        self.explainer = shap.Explainer(self.model)

    def _get_model(self):
        model = CatBoostClassifier()
        model.load_model(PATH_TO_MODEL)
        return model

    def predict(self, aggregates: Aggregates) -> Tuple[float, List[str]]:
        features = pd.DataFrame(self._get_features(aggregates))
        probability = self.model.predict_proba(features)[0, 1]
        signals = None
        if probability > 0.5:
            shap_values = self.explainer.shap_values(features)
            data_frame = pd.DataFrame(shap_values[0].T, columns=["impact"])
            data_frame["name"] = self.input_features
            data_frame["negative_impact"] = data_frame["impact"].abs()
            data_frame = data_frame.sort_values(
                "negative_impact", ascending=False).reset_index(drop=True)
            signals = list(data_frame["name"])[:3]

        return probability, signals

    def _get_features(self, aggregates: Aggregates):
        features = list()
        for aggregate, data in aggregates.aggregates.items():
            data = pd.DataFrame(data.values)
            data[BILLET_POINT] = self._update_coordinates(data[BILLET_POINT])
            data = data.set_index(BILLET_POINT)
            data = data[~data.index.duplicated(keep='first')]
            data.columns = [f"{aggregate}_{col}" for col in data.columns]
            features.append(data)
        features = pd.concat(features, axis=1)
        return self._calculate_features(features)

    def _update_coordinates(self, data):
        return data * RAIL_LEN / data.max()

    def _calculate_features(self, data):
        """Расчет всех фичей ниже производится на основе данных первых 3 метров.
    Перед взятием агрегаций первых 3 метров необходимо привести заготовки на всех проходах к единой длине.

        Фича:
    U0_u0.ds.pos_vert_roll_in_div_u0.ds.pos_vert_roll_out_min
    Расчет:
    min(u0.ds.pos_vert_roll_in / u0.ds.pos_vert_roll_out)

        Фича:
    TDM_UF_2_uf.ds.load_hor_roll.upper_div_uf.axial_displace_lower_shaft_max
    Расчет для данных второго прохода:
    max(uf.ds.load_hor_roll.upper / uf.axial_displace_lower_shaft)

        Фича:
    TDM_UF_3_uf.os.pos_up_hor_roll_div_uf.os.pos_low_hor_roll_max

    Расчет для данных третьего прохода:
    max(uf.os.pos_up_hor_roll / uf.os.pos_low_hor_roll)

        Фича:
    TDM_UF_3_uf.ds.load_vert_roll_div_uf.ds.pos_low_hor_roll_max
    Расчет для данных третьего прохода:
    max(uf.ds.load_vert_roll / uf.ds.pos_low_hor_roll)

        Фича:
    TDM_UF_3_uf.ds.load_vert_roll_div_uf.axial_displace_lower_shaft_max
    Расчет для данных третьего прохода:
    max(uf.ds.load_vert_roll / uf.axial_displace_lower_shaft)

        Фича:
    TDM_UR_2_ur.ds.pos_vert_roll_in_div_ur.ds.pos_vert_roll_out_max
    Расчет для данных второго прохода:
    max(ur.ds.pos_vert_roll_in / ur.ds.pos_vert_roll_out)

        Фича:
    TDM_UR_3_ur.gr27-1.table_pos_before.set_div_ur.ge11-3.ds.line_before.set_mean
    Расчет для данных третьего прохода:
    mean(ur.gr27-1.table_pos_before.set / ur.ge11-3.ds.line_before.set)

        Фича:
    TDM_E_2_e.ur.axial_displace_lower_shaft_std
    Расчет для данных второго прохода:
    std(e.ur.axial_displace_lower_shaft)

        Фича:
    aF_min_0_to_0.29
    Расчет для данных от 0 до 0.29 метров без приведения к общей длине
    min(aF)

        Фича:
    aF_std_6.6_to_9.6
    Расчет для данных от 6.6 до 9.6 метров без приведения к общей длине
    std(aF)
    """

        input_features = dict()
        for input_feature in self.input_features:
            features_names = input_feature.split("_div_")

            aggregator = "_"
            for agg_method in AGG_METHODS:
                if agg_method in features_names[-1]:
                    features_names[-1] = features_names[-1].replace(
                        agg_method, "")
                    aggregator = agg_method

            start = START_POINT
            end = END_POINT
            if "_to_" in features_names[0]:
                first_part, second_part = features_names[0].split("_to_")
                start = float(first_part.split("_")[-1])
                end = float(second_part.split("_")[0])
                features_names[0] = "_".join(["TBK"] +
                                             first_part.split("_")[:-1])

            features = data[features_names[0]]
            if len(features_names) == 2:
                for drop_str in SUBSTR_TO_DROP:
                    if drop_str in features_names[0]:
                        features_names[1] = drop_str + features_names[1]

                features = (data[features_names[0]] /
                            data[features_names[1]]).dropna()

            input_features[input_feature] = [
                self.aggregators.agg_by_method(features[start:end],
                                               aggregator[1:])
            ]

        return input_features


if __name__ == "__main__":
    test_billet_map = {
        'TBK':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\tbk\\file_details\\20230602011928_Л246731030_TBK_1_L.csv',
        'U0':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\U0\\rollings_points_files\\20230602011842_Л246731030_U0_1_L.csv',
        'TDM_UF_1':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UF\\rollings_points_files\\20230602011717_Л246731030_UF_1_L.csv',
        'TDM_UF_2':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UF\\rollings_points_files\\20230602011745_Л246731030_UF_2_L.csv',
        'TDM_UF_3':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UF\\rollings_points_files\\20230602011823_Л246731030_UF_3_L.csv',
        'TDM_UR_1':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UR\\rollings_points_files\\20230602011712_Л246731030_UR_1_L.csv',
        'TDM_UR_2':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UR\\rollings_points_files\\20230602011749_Л246731030_UR_2_L.csv',
        'TDM_UR_3':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\UR\\rollings_points_files\\20230602011817_Л246731030_UR_3_L.csv',
        'TDM_E_1':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\E\\rollings_points_files\\20230602011715_Л246731030_E_1_L.csv',
        'TDM_E_2':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\E\\rollings_points_files\\20230602011747_Л246731030_E_2_L.csv',
        'TDM_E_3':
        '\\\\ZSMK-9684-001\\Data\\2023\\06\\02\\E\\rollings_points_files\\20230602011820_Л246731030_E_3_L.csv'
    }

    aggregates = Aggregates(aggregates=dict())
    for aggregate, file_path in test_billet_map.items():
        usecols = []
        if aggregate == "TBK":
            usecols = ['BilletPoints', 'aF']
        elif aggregate == "U0":
            usecols = [
                'billet_points', 'u0.ds.pos_vert_roll_in',
                'u0.ds.pos_vert_roll_out'
            ]
        elif aggregate == "TDM_UF_2":
            usecols = [
                'billet_points', 'uf.ds.load_hor_roll.upper',
                'uf.axial_displace_lower_shaft'
            ]
        elif aggregate == "TDM_UF_3":
            usecols = [
                'billet_points', 'uf.os.pos_up_hor_roll',
                'uf.os.pos_low_hor_roll', 'uf.ds.load_vert_roll',
                'uf.ds.pos_low_hor_roll', 'uf.axial_displace_lower_shaft'
            ]
        elif aggregate == "TDM_UR_2":
            usecols = [
                'billet_points', 'ur.ds.pos_vert_roll_in',
                'ur.ds.pos_vert_roll_out'
            ]
        elif aggregate == "TDM_UR_3":
            usecols = [
                'billet_points', 'ur.gr27-1.table_pos_before.set',
                'ur.ge11-3.ds.line_before.set'
            ]
        elif aggregate == "TDM_E_2":
            usecols = ['billet_points', 'e.ur.axial_displace_lower_shaft']

        if len(usecols) > 0:
            data = pd.read_csv(file_path,
                               sep=";",
                               decimal=",",
                               usecols=usecols).rename(
                                   columns={'BilletPoints': 'billet_points'})
            aggregates.aggregates[aggregate] = Features(values=data.to_dict(
                orient='list'))

    model = Model()
    model.predict(aggregates)
