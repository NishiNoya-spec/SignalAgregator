import os
from glob import glob

import pandas as pd

PATH_TO_DATA = r"D:\malyarov_dv\Projects\full_data\MNLZ\*"
OUTPUT_DIR = r"D:\malyarov_dv\Projects\full_data\MNLZ"
BILLET_ID = "BilletId"
DROP_COLS = ["EndMoment"]
crossing_distance = 0.25


def get_new_columns_names(columns):
    new_columns = list()
    for col in columns:
        split_name = col.split(".")
        if len(split_name) > 1:
            new_columns.append(".".join(split_name[1:]))
        else:
            new_columns.append(col)
    return new_columns


def cross_billets(all_billets, filenames):
    billets_ids = list(all_billets[BILLET_ID].drop_duplicates(keep='first'))
    new_billets = dict()
    prev_billet = pd.DataFrame()

    for i, billet_id in enumerate(billets_ids):
        billet = all_billets[all_billets[BILLET_ID] == billet_id]
        new_billet = billet.copy()
        if len(prev_billet) > 0:
            new_billet = pd.concat([prev_billet, new_billet])
        if i < len(billets_ids) - 1:
            next_billet = all_billets[all_billets[BILLET_ID] == billets_ids[i +
                                                                            1]]
            next_billet = next_billet[
                next_billet["BilletPoints"] <= crossing_distance]
            next_billet["BilletPoints"] = new_billet["BilletPoints"].max(
            ) + next_billet["BilletPoints"]
            new_billet = pd.concat([new_billet, next_billet])

        new_billets[billet_id] = new_billet.drop(columns=[BILLET_ID])
        raw_filename = filenames[billet_id].split(".")
        filename_part1 = [raw_filename[0][:-5]]
        filename = filename_part1[0]+"_"+raw_filename[1]+"."+raw_filename[2]
        # filename = ".".join(filename_part1 + raw_filename[1:])

        new_billets[billet_id].to_csv(os.path.join(OUTPUT_DIR, filename),
                                      sep=";",
                                      decimal=",")
        prev_billet_len = billet["BilletPoints"].max()
        prev_billet = billet[billet["BilletPoints"] >= (prev_billet_len -
                                                        crossing_distance)]
        prev_billet[
            "BilletPoints"] = prev_billet["BilletPoints"] - prev_billet_len

    return new_billets


def preprocess_data():
    for aggregate_path in glob(PATH_TO_DATA):
        mnlz_aggregate_data = list()
        filenames = dict()
        for billet_path in glob(os.path.join(aggregate_path, "*.csv")):
            print(f"Processing {billet_path} ...")
            filename = os.path.split(billet_path)[-1]
            billet_id = filename.split("_")[1]
            filenames[billet_id] = filename

            data = pd.read_csv(billet_path,
                               sep=";",
                               decimal=",",
                               encoding="windows-1251").drop(columns=DROP_COLS)
            data.columns = get_new_columns_names(data.columns)

            data[BILLET_ID] = billet_id
            data["Moment"] = pd.to_datetime(data["Moment"])

            mnlz_aggregate_data.append(data.set_index("Moment", drop=True))

        all_billets = pd.concat(mnlz_aggregate_data).sort_index()
        new_billets = cross_billets(all_billets, filenames)


if __name__ == '__main__':
    preprocess_data()
