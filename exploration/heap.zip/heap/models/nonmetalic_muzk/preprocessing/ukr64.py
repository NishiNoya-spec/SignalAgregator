import os
from glob import glob
import pandas as pd

step = 0.25
BILLET_ID = "BilletId"
SIGNALS = ["BilletPoint",
           "BrakOperator",
           "length",
           "flaw_type",
           "channel_name",
           "ampl",
           "depth",
           ]
channels_names = {"A1": "A1-A2",
                 "A2": "A1-A2",
                 "A3": "A3-A4",
                 "A4": "A3-A4",
                 "A5": "A5-A6",
                 "A6": "A5-A6",
                 "A7": "A7-A8",
                 "A8": "A7-A8",
                 "B1": "B1-B2",
                 "B2": "B1-B2",
                 "B3": "B3-B4",
                 "B4": "B3-B4",
                 "D1": "D1-D2",
                 "D2": "D1-D2",
                 "D3": "D3-D4",
                 "D4": "D3-D4",
                 "F1": "F1-F2",
                 "F2": "F1-F2",
                 "F3": "F3-F4",
                 "F4": "F3-F4",
                 "C1": "C1-C2",
                 "C2": "C1-C2",
                 "C3": "C3-C4",
                 "C4": "C3-C4",
                 "C5": "C5-C6",
                 "C6": "C5-C6",
                 "C7": "C7-C8",
                 "C8": "C7-C8",
                 "C9": "C9-C10",
                 "C10": "C9-C10",
                 "C11": "C11-C12",
                 "C12": "C11-C12",
                 }

MAIN_CSV_COLUMNS = ["UniqueStringIDLnk", "LengthRail"]
PATH_TO_DATA = r"D:\malyarov_dv\Projects\full_data\ukr64\20230326110453_250\ukr64"
UKR64_OUTPUT_DIR = r"D:\malyarov_dv\Projects\full_data\ukr64\20230326110453_250"


def convert_data(paths: list, main_csv_path: str, operator_brak:bool):
    billets_lengths = pd.read_csv(main_csv_path, sep=";", decimal=",", usecols=MAIN_CSV_COLUMNS, encoding="windows-1251")
    billets_lengths["LengthRail"] = billets_lengths["LengthRail"]/1000
    billets_lengths["UniqueStringIDLnk"] = "Л" + billets_lengths["UniqueStringIDLnk"].str.split("_", expand=True)[0].str.replace("A", "")
    billets_lengths = billets_lengths.set_index("UniqueStringIDLnk").T.to_dict('list')
    for i, path in enumerate(paths):
        print(f"Processing {path} ...")
        filename = os.path.split(path)[-1]
        billet_id = "Л"+filename.split("_")[1].replace("X", "")
        billet_length = billets_lengths[billet_id][0]
        billet_points = pd.DataFrame({"BilletPoint": [step*x for x in range(int(billet_length/step))]}).set_index("BilletPoint")
        data = pd.read_csv(path, sep=";", decimal=",", usecols=SIGNALS, encoding="windows-1251").set_index("BilletPoint")
        if operator_brak:
            data = data[data["BrakOperator"].astype(int) == 1]
        data = data.replace({"channel_name": channels_names})
        grouped_data = list()
        for group_name, df in data.groupby("channel_name"):
            df = df.drop(columns=["channel_name"])
            defectoscopist_col = df["BrakOperator"]
            df = df.drop(columns=["BrakOperator"])
            df.columns = [group_name + "." + col for col in df.columns]
            df.insert(0, "BrakOperator", defectoscopist_col)
            grouped_data.append(df)

        pd.concat(grouped_data+[billet_points]).sort_index().to_csv(os.path.join(PATH_TO_DATA, UKR64_OUTPUT_DIR, filename), sep=";", decimal=",")

def compile_ukr64_into_one_file(paths: list, operator_brak:bool):
    all_data = list()
    for i, path in enumerate(paths):
        print(f"Processing {path} ...")
        filename = os.path.split(path)[-1].split("_")
        billet_id = "Л" + filename[1].replace("X", "")
        moment = pd.to_datetime(filename[0], format='%Y%m%d%H%M%S')
        data = pd.read_csv(path, sep=";", decimal=",", usecols=SIGNALS, encoding="windows-1251")
        data[BILLET_ID] = billet_id
        data["moment"] = moment
        if operator_brak:
            data = data[data["BrakOperator"].astype(int) == 1]
            if len(data) == 0:
                continue

        data = data.drop(columns=["BrakOperator"])

        data = data.replace({"channel_name": channels_names})
        all_data.append(data)

    pd.concat(all_data).sort_values(by=['moment', "BilletPoint"]).set_index("moment").to_csv("all_ukr64.csv", sep=";", decimal=",")


if __name__ == '__main__':
    # main_path = glob(os.path.join(PATH_TO_DATA, "*.csv"))[0]
    # convert_data(glob(os.path.join(PATH_TO_DATA,  "rail_defect_points", "*.csv")), main_path, operator_brak=False)
    compile_ukr64_into_one_file(glob(os.path.join(PATH_TO_DATA,  "rail_defect_points", "*.csv")), operator_brak=True)
