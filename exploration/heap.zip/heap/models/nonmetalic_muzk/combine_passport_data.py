import os
from glob import glob
import pandas as pd

PASSPORT_PATH = os.path.join(
    r"D:\malyarov_dv\Projects\preprocessing_for_9684_passport\result",
    "passport", "*.csv")

PASSPORT_TTD_PATH = os.path.join(
    r"D:\malyarov_dv\Projects\preprocessing_for_9684_passport\result",
    "passport_ttd", "*PASSPORTS_TTD.csv")
MELT_NUMBER = "melt_number"
STRAND_NUMBER = "strand_number"
PASSPORTS_TTD_SIGNALS = [
    MELT_NUMBER,
    "steel_grade",
    "type",
    "c",
    "sn",
    "mn",
    "si",
    "p",
    "s",
    "cr",
    "ni",
    "cu",
    "al",
    "ti",
    "mo",
    "v",
    "nb",
    "n",
    "sb",
]
PASSPORTS_SIGNALS = [
    MELT_NUMBER,
    "shift_foreman",
    "shift_number",
    "sequence_number",
    "ladle_open_moment",
    "ladle_close_moment",
    "tundish_number",
    "mold_powder_al2o3",
    "mold_powder_sio2",
    "mold_powder_f",
    "mold_powder_cao",
    "mold_powder_mgo",
    "mold_powder_moist",
    "mold_powder_na2o_k2o",
    "mold_powder_fe2o3",
]
PASSPORT_MOLD_STRAND_SIGNALS = [
    MELT_NUMBER,
    STRAND_NUMBER,
    "mold_num",
    "mold_life",
]

PASSPORT_HYDROGEN_MEASUREMENTS_SIGNALS = [
    MELT_NUMBER,
    "value",
    "kf_value",
]

LADLE_OPEN_TIME_COLUMNS = ["ladle_open_moment", "ladle_close_moment"]
STEEL_TYPE_COLUMN_NAME = "type"
STEEL_TYPE = "Маркировочная"


def read_data(path, usecols):
    return pd.read_csv(
        path,
        sep=";",
        decimal=",",
        usecols=usecols,
        encoding="windows-1251",
    )


def get_raw_passport_data():
    paths = glob(PASSPORT_PATH)
    raw_passport_data = pd.DataFrame()
    for path in paths:
        file_name = os.path.split(path)[-1]
        df = pd.DataFrame()
        if "PASSPORTS" in file_name:
            df = read_data(path, PASSPORTS_SIGNALS)
            start_time = pd.to_datetime(df[LADLE_OPEN_TIME_COLUMNS[0]])
            end_time = pd.to_datetime(df[LADLE_OPEN_TIME_COLUMNS[1]])
            df["open_ladle_time"] = abs(
                (start_time - end_time).dt.total_seconds())
            df = df.drop(columns=LADLE_OPEN_TIME_COLUMNS)

        elif "PASSPORT_MOLD_STRAND" in file_name:
            df = read_data(path, PASSPORT_MOLD_STRAND_SIGNALS)
        elif "PASSPORT_HYDROGEN_MEASUREMENTS" in file_name:
            df = read_data(path, PASSPORT_HYDROGEN_MEASUREMENTS_SIGNALS)
            df = df[df["value"] < 1.5]
            df = df.groupby(MELT_NUMBER).agg(["max", "min"])
            df.columns = [f"{col[0]}_{col[1]}" for col in df.columns]
            df = df.reset_index()

        if len(df) > 0:
            if len(raw_passport_data) == 0:
                raw_passport_data = df
            else:
                raw_passport_data = raw_passport_data.merge(df, on=MELT_NUMBER)
    return raw_passport_data


def get_raw_ttd_passports_data():
    path = glob(PASSPORT_TTD_PATH)[0]
    raw_ttd_passports_data = read_data(path, PASSPORTS_TTD_SIGNALS)
    return raw_ttd_passports_data[
        raw_ttd_passports_data[STEEL_TYPE_COLUMN_NAME] == STEEL_TYPE].drop(
            columns=STEEL_TYPE_COLUMN_NAME)


def combine_passports_data():
    raw_ttd_passports_data = get_raw_ttd_passports_data()
    raw_passport_data = get_raw_passport_data()

    mereged_df = pd.merge(
        raw_ttd_passports_data,
        raw_passport_data,
        on=MELT_NUMBER,
    )

    temp_cols = mereged_df.columns.tolist()
    index = mereged_df.columns.get_loc(STRAND_NUMBER)
    new_cols = temp_cols[0:2] + [temp_cols[index]
                                 ] + temp_cols[2:index] + temp_cols[index + 1:]
    return mereged_df[new_cols]


if __name__ == '__main__':
    passport_data = combine_passports_data()
    passport_data.to_csv(
        "combined_passports_data.csv",
        sep=";",
        decimal=",",
        index=False,
        encoding="windows-1251",
    )
