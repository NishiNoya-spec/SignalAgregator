import os
import pandas as pd
from glob import glob

PATH_TO_PASPORT_DATA = r"combined_passports_data.csv"
PATH_TO_NONMETALLIC_INCLUDES_DATA = r"ukr64-result\*.csv"
PATH_TO_RESULT = r"nonmetalic"
if __name__ == '__main__':
    passports_data = pd.read_csv(
        PATH_TO_PASPORT_DATA,
        sep=";",
        decimal=",",
        encoding="windows-1251",
    )
    passports_data_columns = list(passports_data.columns)

    for billet_path in glob(PATH_TO_NONMETALLIC_INCLUDES_DATA):
        file_name = os.path.split(billet_path)[-1]
        billet_id = file_name.split("_")[1]

        melt_number = int(billet_id[1:5])
        strand_number = int(billet_id[6])
        passport_data = passports_data[(passports_data["strand_number"].astype(int) == strand_number) &
                                     (passports_data["melt_number"].str.split("-", expand=True)[2].astype(int) == melt_number)]
        if len(passport_data) > 0:
            df = pd.read_csv(billet_path, sep=";", decimal=",")
            df[passports_data_columns] = passport_data
            df.to_csv(os.path.join(PATH_TO_RESULT, file_name), sep=";", decimal=",", encoding="windows-1251",)

