import os
import warnings

import numpy as np
import pandas as pd
import tqdm
from evraz.datascience import (CLASSIFICATION_MODELS, EDA, SPLITTERS,
                               TASK_TYPES, Experiment, ModelTrainer)

warnings.filterwarnings('ignore')

PATH_TO_COMBINED_MELT_GENERAL_DATA = \
    'D:/malyarov_dv/Projects/preprocessing_for_9684_passport/' \
    'result/combined_passports_data.csv'
PATH_TO_U0_UF_UKR_DATA = \
    'D:/malyarov_dv/Projects/preprocessing_for_9684_part_1/result'
target = 'classification_BrakOperator_max'


def preprocessing():
    # чтение паспортных данных
    passports = pd.read_csv(PATH_TO_COMBINED_MELT_GENERAL_DATA,
                            encoding="windows-1251",
                            delimiter=";")

    # чтение подготовленных данных с U0, UF и UKR64
    list_files = os.listdir(PATH_TO_U0_UF_UKR_DATA)
    files = []
    for file_name in tqdm.tqdm(list_files):
        file = pd.read_csv(f'{PATH_TO_U0_UF_UKR_DATA}/{file_name}')
        files.append(file)
    main_data = pd.concat(files)

    # редактируем id рельса для соединения данных
    billet_ids = []
    for melt_number, strand_number in \
            zip(passports['melt_number'], passports['strand_number']):
        billet_id = 'Л2' + str(melt_number[-4:]) + str(strand_number)
        billet_ids.append(billet_id)
    passports['BilletIdNew'] = billet_ids
    main_data['BilletIdNew'] = main_data['BilletId'].apply(lambda x: x[:-2])

    # объединение данных
    full_data = pd.merge(main_data, passports, on='BilletIdNew')

    # заменяем , на . чтобы превратить object столбцы в числовые
    for col in full_data.columns:
        try:
            full_data[col] = full_data[col].apply(
                lambda x: float(x.replace(",", ".")))
        except Exception:
            pass

    # заполнение пропусков и замена inf
    full_data = full_data.fillna(-99999)
    full_data = full_data.replace(-np.inf, -999999)
    full_data = full_data.replace(np.inf, 999999)

    # отбор переменных по корреляциям
    saved_features = []
    for col in tqdm.tqdm(full_data.columns):
        try:
            corr_value = abs(full_data[[target, col]].corr().values[0][1])
            if corr_value > 0.21:
                saved_features.append(col)
        except Exception:
            pass

    full_data = full_data[saved_features]

    # убираем столбец - источник целевой переменной
    full_data = full_data.drop(columns='BrakOperator_max')
    return full_data


def set_experiment(full_data):
    # настройка эксперимента
    experiment = Experiment(
        EDA.Correlations,
        EDA.Histograms,
        EDA.DescribeFeatures,
        ModelTrainer.TrainModel,
    )
    model_params = {
        "Linear": {
            "class_weight": "balanced",
        },
        "CatBoost": {
            "iterations": 1000,
            "early_stopping_rounds": 10,
            "learning_rate": 0.1,
            "random_seed": 0,
            "depth": 4,
            "auto_class_weights": 'Balanced'
        },
    }
    # запуск эксперимента
    for model_type in [
            CLASSIFICATION_MODELS.CatBoost,
            CLASSIFICATION_MODELS.Linear,
    ]:
        experiment.start(full_data,
                         task_type=TASK_TYPES.CLASSIFICATION,
                         target=target,
                         model_type=model_type,
                         model_params=model_params[model_type.value],
                         splitter=SPLITTERS.StratifiedKFold,
                         run_name="agg_by_full_length_rail")


if __name__ == "__main__":
    full_data = preprocessing()
    set_experiment(full_data=full_data)
