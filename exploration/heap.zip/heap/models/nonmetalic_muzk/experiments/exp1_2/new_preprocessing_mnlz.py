import math
import os
from multiprocessing import cpu_count, pool

import pandas as pd
from pympler import asizeof

from exploration.experiments_aggregation import (data_mapping, dto,
                                                 new_generator, processer)
""" Алгоритм агрегации данных заготовок для последующего анализа

    ---- НАСТРОЙКА АГРЕГАЦИИ ДАННЫХ ----

    Аргументы настройки вычисления длин (measurements):
        "abs" - абсолютные значения длин в метрах.
        Отрицательные значения - вычисляются от конца отрезка,
                строковый аргумент "end" обозначает конечную точку рельса.
        "rel" - относительные длины в процентах,
        автоматически пересчитываются алгоритмом в абсолютные длины.
    Настройка вторичной агрегации производится передачей листа
    с методом агрегации по 0 индексу и
    длиной агрегации по 1 индексу.
    Аргументы настройки вторичного метода агрегации (inner_method):
        "by_n_meters" - агрегация по равномерным отрезкам длиной N метров,
        величина N равна аргументу по 1 индексу.
        "all" - агрегируется весь заданный отрезок целиком,
        аргумент по 1 индексу в таком случае игнорируется
    Аргумент сопоставления данных таргетов и фичей (main_method):
        "one-to-one" - последовательно сопоставляются значения таргетов
        и фичей таким образом, что кажому отдельному
        значению таргета сопоставляется отдельное значение фичи.
        При это, если количество фичей и таргетов
                       не равно, сопоставляются n меньших значений.
        "all-to-one" - последовательно для каждого таргета сопоставляются
        значения всех фичей по всем сгенерированным отрезкам
        ---- РАСПОЛОЖЕНИЕ ФАЛОВ С ДАННЫМИ ----
    Для каждой указанной в DataPaths папки внутри ищется папка формата ./csv
    внутри которой должны находиться файлы с данными
"""

available_cores = cpu_count() - 2
data_folder = r"D:\malyarov_dv\Projects\preprocessing_for_9684_part_2"

constants = dto.Constants(
    NUM_OF_CORES=available_cores,
    DATA_PATHS={
        "ukr64": os.path.join(data_folder, "ukr64"),
        "mnlz": os.path.join(data_folder, "mnlz"),
    },
    DATA_TYPES={
        "ukr64": "target",
        "mnlz": "features",
    },
    AGGREGATION=dto.Aggregation(
        target_segments=[
            [0, "end"],
            # [3.75, 6.75]
        ],
        target_measurement="abs",
        target_inner_method=["all", None],
        features_segments=[
            [0, "end"],
            # [3.75, 6.75]
        ],
        features_measurement="abs",
        features_inner_method=["all", None],
        main_method="one-to-one"),
    MARK_FILTER=False,
    INTERPOLATE=True,
    MARK='Э76ХФ',
    PATH_TO_METADATA=os.path.join(data_folder, "metadata/*xlsx"),
    PATH_TO_RESULT=os.path.join(data_folder, "result"),
    BILLET_ID="BilletId",  # Устарело
    BILLET_POINT="billet_points",
    FEATURES_TO_DROP=[
        'speed', 'u0.descaling.pressure.extrapolated', 'moment', 'Unnamed: 0',
        "Moment"
    ],
    TARGET="BrakOperator",
    FORBIDDEN_FEATURES=[
        "Time",
        "moment",
        "BilletId",
        "billet_points",
        "BilletPoints",
        "BilletPoint",
    ],
    TARGET_AGG_METHODS=[
        "max",
        # "mean",
        # "std"
    ],
    FEATURES_AGG_METHODS=[
        "min",
        "max", "mean", "skew", new_generator.tg
    ],
)  # Устарело


def preprocessing():
    creator = data_mapping.MappingCreator(constants=constants)
    metadata = creator.get_metadata()
    mapping = creator.create_mapping(metadata=metadata)

    main_processer = processer.Processer(constants=constants,
                                         metadata=metadata,
                                         data_mapping=mapping)

    # Оркестратор
    multiproc_queue = []
    for n in range(math.ceil(len(mapping) / constants.NUM_OF_CORES)):
        multiproc_queue.append(
            list(mapping.keys())[(constants.NUM_OF_CORES *
                                  n):(constants.NUM_OF_CORES * (n + 1))])

    batches, batches_size, start_cut, end_cut = [], 0, 0, 0
    for cut in multiproc_queue:

        # Debug
        # a = main_processer.create_data_batch(cut[1])

        with pool.Pool(constants.NUM_OF_CORES) as p:
            batch = p.map(main_processer.create_data_batch, cut)

        for billet_batch in batch:
            if billet_batch is not None:
                batches += billet_batch

        batches_size += asizeof.asizeof(batch[0]) * len(batch)
        end_cut += len(cut)
        del batch

        # 4 * 10**9 максимальный размер датасета в оперативке
        if batches_size > 1:
            if not os.path.exists(constants.PATH_TO_RESULT):
                os.makedirs(constants.PATH_TO_RESULT)
            print(constants.PATH_TO_RESULT + f'/{start_cut}_to_{end_cut}.csv')
            df = pd.DataFrame(batches)
            df.to_csv(
                os.path.join(constants.PATH_TO_RESULT,
                             f'{start_cut}_to_{end_cut}.csv'))

            start_cut, batches, batches_size = end_cut + 1, [], 0


if __name__ == "__main__":
    preprocessing()
    a = 1
