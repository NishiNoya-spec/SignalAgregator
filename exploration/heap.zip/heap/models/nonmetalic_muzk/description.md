#Описание формирования файла для анализа
##Описание формирования combined_passports_data

##Назначение
1) Данные в файле являются входными значениями для построения моделей определения дефектов: неметаллические включения
2) Файл испльзуется совместно с привязанными к длине данными: МНЛЗ, стана, TBK, РПК и LNK100

##Вход
Файл формируется из файлов выгрузок по паспорту плавки:
*_PASSPORTS.csv
*_PASSPORT_HYDROGEN_MEASUREMENTS.csv
*_PASSPORT_MOLD_STRANDS.xlsx
*_PASSPORTS_TTD.csv
Выгрузку возможно получить [здесь](http://tpqc-zsmk-9684-dev.apps.ocpd.sib.evraz.com/api/export/params)

##Обработка

###*_PASSPORTS_TTD
Из таблицы берется список сигналов:
    `melt_number,
     steel_grade,
     type,
     c,
     sn,
     mn,
     si,
     p,
     s,
     cr,
     ni,
     cu,
     al,
     ti,
     mo,
     v,
     nb,
     n,
     sb`
Значения фильтруются по **_type_** = Маркировочная, затем **_type_** удаляется

###*_PASSPORTS
Из таблицы берется список сигналов:
    `melt_number,
    shift_foreman,
    shift_number,
    sequence_number,
    ladle_open_moment,
    ladle_close_moment,
    tundish_number,
    mold_powder_al2o3,
    mold_powder_sio2,
    mold_powder_f,
    mold_powder_cao,
    mold_powder_mgo,
    mold_powder_moist,
    mold_powder_na2o_k2o,
    mold_powder_fe2o3 `
 Сигналы **_ladle_open_moment_** и **_ladle_close_moment_** заменяются на **_open_ladle_time_** = **_ladle_open_moment_** - **_ladle_close_moment_** 

###*_PASSPORT_MOLD_STRAND
Из таблицы берется список сигналов:
    `melt_number,
    strand_number,
    mold_num,
    mold_life`

###*_PASSPORT_HYDROGEN_MEASUREMENTS_SIGNALS
Из таблицы берется список сигналов:
    `melt_number,
    value,
    kf_value`
 В таблице остаются значения: удволетворяющие условию  **_value_** <=1.5.
 Столбцы **_value_** и **_kf_value_** заменяются на максимальные и минимальные значения по плавкам.
    
##Выход
Выходом является слияние всех обработанных таблиц по столбцу **_melt_number_**

